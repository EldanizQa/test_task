export const baseUrl = 'https://image.tmdb.org/t/p/original/'
