Neftlix Clone Project

The tools I have used :
 -Typescript
 -NextJs
 -Material UI
 -Tailwind Css
 -Firebase
 -Stripe for payment proccess


This is a completely responsive website.The actions can be made :

 -Sign in Sign up 
 -Payment
 -Watch Trailer
 -Scroll Movie List
 -Add movie to watch list

I have used TMDB API.For testing the project you have to go to tmdb api website and get a api key.
Put it in the env file and run the project.

To run the project:

npm run dev